var angular_app = function () {
  // wow initiate
  var wow = new WOW({
    animateClass: "animated",
    offset: 50,
  });
  wow.init();
};
